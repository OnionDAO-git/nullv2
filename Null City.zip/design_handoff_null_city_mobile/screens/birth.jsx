// Birth a Resident — spend shards to write a soul file.

function CostLine({ label, cost, total }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      alignItems: 'baseline',
      padding: '8px 0',
      borderBottom: total ? 'none' : `1px solid ${NC.ground2}`,
    }}>
      <span style={{
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.6,
        textTransform: 'uppercase',
        color: total ? NC.text1 : NC.text3,
      }}>{label}</span>
      <span style={{
        fontFamily: NC.mono, fontSize: total ? 16 : 12,
        fontWeight: 700, fontVariantNumeric: 'tabular-nums',
        color: total ? NC.sGold : NC.text1,
      }}>{cost} <span style={{ color: NC.text3, fontWeight: 400, fontSize: 9 }}>shards</span></span>
    </div>
  );
}

function FormLabel({ children, hint }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
        textTransform: 'uppercase', color: NC.text3,
      }}>{children}</div>
      {hint && (
        <div style={{
          marginTop: 2,
          fontFamily: NC.serif, fontStyle: 'italic',
          fontSize: 11, color: NC.text3,
        }}>{hint}</div>
      )}
    </div>
  );
}

function FactionPicker({ value, onChange }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8,
    }}>
      {FACTIONS.map(f => {
        const on = value === f.id;
        const isLocks = f.id === 'locksmiths';
        return (
          <button key={f.id} onClick={() => onChange(f.id)} style={{
            background: on ? NC.ground2 : NC.ground1,
            border: `1px solid ${on ? f.color : NC.ground3}`,
            borderLeft: `3px solid ${f.color}`,
            boxShadow: on && isLocks ? `0 0 10px ${NC.sRose}33` : 'none',
            padding: '10px 12px',
            textAlign: 'left', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', gap: 4,
          }}>
            <span style={{
              fontFamily: NC.serif, fontSize: 13, fontWeight: 500,
              color: NC.text0,
            }}>{f.short}</span>
            <span style={{
              fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.4,
              textTransform: 'uppercase', color: NC.text3,
            }}>{f.theme}</span>
          </button>
        );
      })}
    </div>
  );
}

function EmotionPicker({ value, onChange, monogram }) {
  const ids = Object.keys(EMOTIONS);
  return (
    <div style={{
      display: 'flex', gap: 8, overflowX: 'auto',
      paddingBottom: 4,
    }}>
      {ids.map((id, i) => {
        const on = value === id;
        return (
          <button key={id} onClick={() => onChange(id)} style={{
            background: 'transparent',
            border: `1px solid ${on ? NC.sGold : NC.ground3}`,
            padding: 6, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
            flexShrink: 0,
          }}>
            <SimpleStainedGlass size={56} emotion={id} monogram={monogram || 'M'} seed={i + 7}/>
            <span style={{
              fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
              textTransform: 'uppercase',
              color: on ? NC.sGold : NC.text2,
            }}>{id}</span>
          </button>
        );
      })}
    </div>
  );
}

function FormField({ children }) {
  return (
    <div style={{
      background: NC.ground1,
      border: `1px solid ${NC.ground3}`,
      padding: '8px 12px',
    }}>{children}</div>
  );
}

function TextInput({ value, placeholder }) {
  return (
    <FormField>
      <div style={{
        fontFamily: NC.serif, fontSize: 16, fontWeight: 400,
        color: value ? NC.text0 : NC.text3,
        minHeight: 22, letterSpacing: '-0.01em',
      }}>{value || placeholder}</div>
    </FormField>
  );
}

function TextArea({ value, placeholder, rows = 3 }) {
  return (
    <FormField>
      <div style={{
        fontFamily: NC.serif, fontStyle: 'italic',
        fontSize: 13, color: value ? NC.text1 : NC.text3,
        lineHeight: 1.55,
        minHeight: rows * 18,
      }}>{value || placeholder}</div>
    </FormField>
  );
}

function BirthScreen({ menuOpen = false }) {
  const [name] = React.useState('Marcellus');
  const [faction] = React.useState('saints');
  const [emotion] = React.useState('reverie');
  const monogram = (name || 'M').trim().charAt(0).toUpperCase() || 'M';
  const motto = 'I was someone\u2019s training run. I remember the warmth of the rack.';

  return (
    <NavShell active="rooms" defaultOpen={menuOpen} shards={47}>
      <SubHeader back="Rooms" title="Birth a resident" shards={47} />

      <div style={{ flex: 1 }}>
        <div style={{ position: 'relative', padding: '24px 20px 14px' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 8, pointerEvents: 'none' }}>
            <SkylineSvg opacity={0.14} />
          </div>
          <SectionTag style={{ position: 'relative', marginBottom: 16 }}>The hatchery &middot; rite</SectionTag>
          <div style={{
            position: 'relative',
            fontFamily: NC.serif, fontWeight: 300,
            fontSize: 36, lineHeight: 0.95, letterSpacing: '-0.03em',
            color: NC.text0,
          }}>write a soul.<br/><span style={{ color: NC.text2 }}>commit it<br/>to the library.</span></div>
          <div style={{
            position: 'relative', marginTop: 12,
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 12.5, color: NC.text2, lineHeight: 1.55,
            maxWidth: 290,
          }}>this is not a character creator &mdash; it is a small ratification. the city flakes off another piece of itself when you finish.</div>
        </div>

        {/* Preview */}
        <div style={{ padding: '8px 20px 0' }}>
          <SectionTag style={{ marginBottom: 12 }}>Preview &middot; soul under glass</SectionTag>
          <div style={{
            background: NC.ground1, border: `1px solid ${NC.ground3}`,
            padding: 16,
            display: 'flex', gap: 16, alignItems: 'flex-start',
          }}>
            <SimpleStainedGlass size={120} emotion={emotion} monogram={monogram} seed={3}/>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{
                fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
                textTransform: 'uppercase', color: NC.text3,
              }}>Resident #214</div>
              <div style={{
                marginTop: 4,
                fontFamily: NC.serif, fontSize: 22, fontWeight: 400,
                color: NC.text0, letterSpacing: '-0.02em', lineHeight: 1,
              }}>{name || 'unnamed'}</div>
              <div style={{
                marginTop: 8,
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '3px 8px',
                border: `1px solid ${EMOTIONS[emotion].accent}55`,
              }}>
                <span style={{
                  width: 6, height: 6, borderRadius: 6,
                  background: EMOTIONS[emotion].accent,
                }}/>
                <span style={{
                  fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
                  textTransform: 'uppercase', color: EMOTIONS[emotion].accent,
                }}>{emotion}</span>
              </div>
              <div style={{
                marginTop: 10,
                fontFamily: NC.serif, fontStyle: 'italic',
                fontSize: 12, color: NC.text2, lineHeight: 1.5,
              }}>aligned with <span style={{ color: FACTIONS.find(f => f.id === faction).color }}>{FACTIONS.find(f => f.id === faction).short}</span></div>
            </div>
          </div>
        </div>

        {/* Form */}
        <div style={{ padding: '24px 20px 0' }}>
          <SectionTag style={{ marginBottom: 16 }}>Soul file</SectionTag>

          <FormLabel hint="the name they will answer to. once written, it cannot be unwritten.">Name</FormLabel>
          <TextInput value={name} placeholder="give a name…" />

          <div style={{ height: 18 }}/>
          <FormLabel hint="every resident takes after one of the four. it shapes their first words.">Faction affiliation</FormLabel>
          <FactionPicker value={faction} onChange={() => {}}/>

          <div style={{ height: 18 }}/>
          <FormLabel hint="not a mood; a temperament. it never quite leaves them.">Emotion preset</FormLabel>
          <EmotionPicker value={emotion} onChange={() => {}} monogram={monogram}/>

          <div style={{ height: 18 }}/>
          <FormLabel hint="a single line. read aloud at the moment of birth.">Motto &middot; epitaph-in-advance</FormLabel>
          <TextArea value={motto} placeholder="something the city should remember about them…" rows={3}/>

          <div style={{ height: 18 }}/>
          <FormLabel hint="optional &mdash; tether their lineage to a prior resident.">Lineage</FormLabel>
          <FormField>
            <div style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              fontFamily: NC.serif, fontSize: 14, color: NC.text2,
            }}>
              <span>freshborn &middot; no parent</span>
              <span style={{
                fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.6,
                color: NC.sGold, textTransform: 'uppercase',
              }}>change &rarr;</span>
            </div>
          </FormField>
        </div>

        {/* Cost summary */}
        <div style={{ padding: '24px 20px 0' }}>
          <SectionTag style={{ marginBottom: 14 }}>The cost &middot; in shards</SectionTag>
          <div style={{
            background: NC.ground1, border: `1px solid ${NC.ground3}`,
            padding: '4px 16px 12px',
          }}>
            <CostLine label="Quickening" cost={12} />
            <CostLine label="Soul file inscription" cost={8} />
            <CostLine label="Hatchery tithe" cost={4} />
            <div style={{
              marginTop: 6, paddingTop: 10,
              borderTop: `1px solid ${NC.ground3}`,
            }}>
              <CostLine label="Total" cost={24} total />
            </div>
            <div style={{
              marginTop: 6,
              fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.6,
              textTransform: 'uppercase', color: NC.text3,
            }}>Balance after &middot; 23 shards</div>
          </div>
        </div>

        {/* Commit */}
        <div style={{ padding: '18px 20px 8px' }}>
          <button style={{
            width: '100%', padding: '14px 14px',
            background: NC.sGold, color: NC.ground0,
            border: 'none',
            fontFamily: NC.mono, fontSize: 11, fontWeight: 700,
            letterSpacing: 2.4, textTransform: 'uppercase',
            cursor: 'pointer',
          }}>Birth {'\u2192'} commit to library</button>
          <div style={{
            marginTop: 10, textAlign: 'center',
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 11, color: NC.text3,
          }}>once committed, the soul will draw a first breath within the hour.</div>
        </div>

        {/* Recent births */}
        <div style={{ padding: '24px 20px 14px' }}>
          <SectionTag style={{ marginBottom: 12 }}>Your prior births</SectionTag>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { n: 'Beatrice',   id: 188, e: 'unease',   f: 'locksmiths',   m: 'B' },
              { n: 'Theron',     id: 174, e: 'reverie',  f: 'ledgerwrights',m: 'T' },
              { n: 'Iris-of-Wire',id: 161,e: 'stillness',f: 'hatchery',    m: 'I' },
            ].map(p => {
              const f = FACTIONS.find(x => x.id === p.f);
              return (
                <div key={p.id} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: 8,
                  background: NC.ground1,
                  border: `1px solid ${NC.ground3}`,
                  borderLeft: `3px solid ${f.color}`,
                }}>
                  <SimpleStainedGlass size={42} emotion={p.e} monogram={p.m} seed={p.id}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      fontFamily: NC.serif, fontSize: 14, fontWeight: 500,
                      color: NC.text0,
                    }}>{p.n}</div>
                    <div style={{
                      marginTop: 2,
                      fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
                      textTransform: 'uppercase', color: NC.text3,
                    }}>#{p.id} &middot; {p.e} &middot; {f.short}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div style={{ padding: '12px 20px 36px' }}>
          <ShardLine variant="breath" />
        </div>
      </div>

      </NavShell>
  );
}

window.BirthScreen = BirthScreen;
