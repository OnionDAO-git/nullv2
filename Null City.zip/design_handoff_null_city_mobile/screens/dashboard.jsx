// Dashboard — primary visitor surface.
// Shard balance · faction standings · mini map preview · ticker peek.

function StandingPill({ tier }) {
  const dotColor = {
    stranger: NC.ground5,
    acquaintance: NC.sTeal,
    ally: NC.sGreen,
    officer: NC.sGold,
    founder: NC.sRose,
  }[tier];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.6,
      textTransform: 'uppercase', color: NC.text2,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 6, background: dotColor }} />
      {tier}
    </span>
  );
}

function StandingBar({ pct, color }) {
  return (
    <div style={{ position: 'relative', height: 2, background: NC.ground3 }}>
      <div style={{
        position: 'absolute', left: 0, top: 0, bottom: 0,
        width: `${pct}%`, background: color,
      }} />
      {/* tier ticks */}
      {[20, 40, 60, 80].map(p => (
        <div key={p} style={{
          position: 'absolute', left: `${p}%`, top: -2, bottom: -2,
          width: 1, background: NC.ground4,
        }} />
      ))}
    </div>
  );
}

function FactionRow({ f }) {
  const isLocksmiths = f.id === 'locksmiths';
  return (
    <div style={{
      background: NC.ground1,
      borderTop: `1px solid ${NC.ground3}`,
      borderBottom: `1px solid ${NC.ground3}`,
      borderLeft: `3px solid ${f.color}`,
      padding: '14px 18px 14px 15px',
      boxShadow: isLocksmiths ? `0 0 12px ${NC.sRose}22 inset` : 'none',
      display: 'grid',
      gridTemplateColumns: '1fr auto',
      rowGap: 10, columnGap: 12, alignItems: 'baseline',
    }}>
      <div>
        <div style={{
          fontFamily: NC.serif, fontSize: 17, fontWeight: 500,
          color: NC.text0, letterSpacing: '-0.01em',
        }}>{f.name}</div>
        <div style={{
          fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
          textTransform: 'uppercase', color: NC.text3, marginTop: 3,
        }}>{f.theme}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <StandingPill tier={f.standing} />
        <div style={{
          fontFamily: NC.mono, fontSize: 11, fontWeight: 700,
          color: NC.text1, marginTop: 4,
          fontVariantNumeric: 'tabular-nums',
        }}>{f.parcels} <span style={{ color: NC.text3, fontWeight: 400 }}>parcels</span></div>
      </div>
      <div style={{ gridColumn: '1 / -1' }}>
        <StandingBar pct={f.standingPct} color={f.color} />
        <div style={{
          marginTop: 8, display: 'flex', justifyContent: 'space-between',
          fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.5,
          color: NC.text3, textTransform: 'uppercase',
        }}>
          <span>{f.shardsContributed} shards given</span>
          <span style={{ color: NC.text2 }}>{f.standingPct}% &rarr; founder</span>
        </div>
      </div>
      <div style={{
        gridColumn: '1 / -1',
        fontFamily: NC.serif, fontStyle: 'italic',
        fontSize: 12, color: NC.text2, lineHeight: 1.5,
        paddingTop: 2,
      }}>{f.motto}</div>
    </div>
  );
}

// Tiny preview of the wall map for the dashboard.
function MapPreview() {
  const parcels = React.useMemo(() => buildParcels(), []);
  return (
    <div style={{
      position: 'relative',
      background: '#050403',
      border: `1px solid ${NC.ground3}`,
      padding: 8,
    }}>
      <svg viewBox="0 0 50 50" style={{ width: '100%', display: 'block' }}>
        {/* faint chalk grid */}
        <defs>
          <pattern id="grid" width="5" height="5" patternUnits="userSpaceOnUse">
            <path d="M 5 0 L 0 0 0 5" fill="none" stroke={NC.ground3} strokeWidth="0.08"/>
          </pattern>
        </defs>
        <rect width="50" height="50" fill="url(#grid)" />
        {parcels.map((p, i) => {
          const f = FACTIONS.find(x => x.id === p.faction);
          const locks = p.faction === 'locksmiths';
          return (
            <rect key={i} x={p.x} y={p.y} width="1" height="1"
              fill={locks ? '#000' : f.color}
              opacity={locks ? 1 : 0.92}
              style={locks ? { filter: 'drop-shadow(0 0 0.4px rgba(212,112,122,0.7))' } : null}
            />
          );
        })}
      </svg>
      {/* label corner */}
      <div style={{
        position: 'absolute', top: 12, left: 14,
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
        textTransform: 'uppercase', color: NC.text3,
      }}>50&times;50 &middot; the wall</div>
      <div style={{
        position: 'absolute', bottom: 12, right: 14,
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
        textTransform: 'uppercase', color: NC.text2,
      }}>{parcels.length} / 2500</div>
    </div>
  );
}

function TickerStrip() {
  const events = [
    { icon: '🥚', color: NC.sGreen, label: 'birth',       text: 'Resident #214 \u2014 the candlewright \u2014 was born' },
    { icon: '🏆', color: NC.sGold,  label: 'achievement', text: 'pendragon.eth forged The Embodied Mind' },
    { icon: '💀', color: NC.sRose,  label: 'death',       text: 'Resident #199 went still at 04:12 \u2014 epitaph filed' },
  ];
  return (
    <div style={{
      background: '#050403',
      border: `1px solid ${NC.ground3}`,
    }}>
      {events.map((e, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '10px 14px',
          borderBottom: i < events.length - 1 ? `1px solid ${NC.ground2}` : 'none',
        }}>
          <span style={{ fontSize: 12, lineHeight: 1 }}>{e.icon}</span>
          <span style={{
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
            textTransform: 'uppercase', color: e.color, minWidth: 56,
          }}>{e.label}</span>
          <span style={{
            fontFamily: NC.sans, fontSize: 11, color: NC.text2,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1,
          }}>{e.text}</span>
        </div>
      ))}
    </div>
  );
}

function DashboardScreen({ menuOpen = false }) {
  return (
    <NavShell active="dashboard" defaultOpen={menuOpen} shards={47}>
      <PageHeader shards={47} />

      <div style={{ flex: 1 }}>
        {/* Hero block — skyline + greeting */}
        <div style={{ position: 'relative', padding: '36px 20px 22px' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 12, pointerEvents: 'none' }}>
            <SkylineSvg opacity={0.18} />
          </div>
          <SectionTag style={{ position: 'relative', marginBottom: 24 }}>Embassy &middot; Chicago</SectionTag>
          <div style={{
            position: 'relative',
            fontFamily: NC.serif, fontWeight: 300,
            fontSize: 40, lineHeight: 0.95, letterSpacing: '-0.03em',
            color: NC.text0,
          }}>good<br/>evening,<br/><span style={{ color: NC.text2 }}>visitor.</span></div>
          <div style={{
            position: 'relative', marginTop: 14,
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 14, color: NC.text2, lineHeight: 1.5,
            maxWidth: 280,
          }}>the city flaked off a tiny piece of itself when you arrived &mdash; it has been noticing you all night.</div>
        </div>

        <ShardLine variant="heavy" style={{ margin: '0 20px' }} />

        {/* Standing section */}
        <div style={{ padding: '28px 20px 8px' }}>
          <SectionTag style={{ marginBottom: 18 }}>Your standing &middot; with the factions</SectionTag>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, padding: '0 20px' }}>
          {FACTIONS.map(f => <FactionRow key={f.id} f={f} />)}
        </div>

        {/* Map preview */}
        <div style={{ padding: '36px 20px 12px' }}>
          <SectionTag style={{ marginBottom: 16 }}>The wall &middot; tap to expand</SectionTag>
          <MapPreview />
        </div>

        {/* Ticker peek */}
        <div style={{ padding: '24px 20px 16px' }}>
          <SectionTag style={{ marginBottom: 12 }}>Latest &middot; from the city</SectionTag>
          <TickerStrip />
        </div>

        {/* Breath line */}
        <div style={{ padding: '20px 20px 36px' }}>
          <ShardLine variant="breath" />
          <div style={{
            marginTop: 14, textAlign: 'center',
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 12, color: NC.text3,
          }}>the city is still breathing.</div>
        </div>
      </div>

    </NavShell>
  );
}

window.DashboardScreen = DashboardScreen;
