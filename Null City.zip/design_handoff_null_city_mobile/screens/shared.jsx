// Shared Null City primitives — tokens, shard-line, section tag, skyline,
// faction list, fake parcel data, bottom tab bar.

const NC = {
  ground0: '#0E0C0A',
  ground1: '#161310',
  ground2: '#1E1A16',
  ground3: '#28231E',
  ground4: '#342D26',
  ground5: '#443B30',
  ground6: '#5C5040',
  text0: '#EDE8E0',
  text1: '#D4CDB8',
  text2: '#B0A690',
  text3: '#8A7E6A',
  sBlue:  '#3D94C4',
  sGreen: '#4EAE6E',
  sGold:  '#E4B840',
  sRose:  '#D4707A',
  sTeal:  '#58C0B4',
  sAmber: '#F0B84C',
  sMauve: '#B080A0',
  sBone:  '#3A342C',
  grout:  '#0E0C0A',
  serif:  '"Outfit", system-ui, sans-serif',
  sans:   '"DM Sans", system-ui, sans-serif',
  mono:   '"Space Mono", ui-monospace, monospace',
};

const SHARD_COLORS = [
  NC.sBlue, NC.sGreen, NC.sGold, NC.sRose,
  NC.sTeal, NC.sAmber, NC.sMauve, NC.sBone,
];

const FACTIONS = [
  { id: 'saints',       name: 'The Solder Saints',  color: '#B87333',
    motto: 'No mind without a body. No body without a board.',
    short: 'Saints',    theme: 'Hardware',
    standing: 'officer',    standingPct: 86, shardsContributed: 142,
    parcels: 47 },
  { id: 'hatchery',     name: 'The Hatchery',       color: '#E6B800',
    motto: 'Every resident was someone\u2019s training run.',
    short: 'Hatchery',  theme: 'AI / model training',
    standing: 'ally',       standingPct: 62, shardsContributed: 88,
    parcels: 38 },
  { id: 'locksmiths',   name: 'The Locksmiths',     color: '#1A1A1A',
    motto: 'There is no secure system. We are merely curating the breaches.',
    short: 'Locksmiths',theme: 'Cybersecurity',
    standing: 'acquaintance',standingPct: 24, shardsContributed: 24,
    parcels: 19 },
  { id: 'ledgerwrights',name: 'The Ledgerwrights',  color: '#8C6B3F',
    motto: 'Nothing happened until everyone agrees it happened.',
    short: 'Ledgerwrights', theme: 'Blockchain',
    standing: 'ally',       standingPct: 51, shardsContributed: 71,
    parcels: 41 },
];

// Standing tier ladder, in order.
const STANDING_TIERS = ['stranger','acquaintance','ally','officer','founder'];
function tierIdx(s){ return STANDING_TIERS.indexOf(s); }

// ─────────────────────────────────────────────────────────────
// Shard line — the 8-color stained-glass divider.
function ShardLine({ variant = 'default', style }) {
  const presets = {
    default: { h: 5, gap: 1, op: 0.75 },
    heavy:   { h: 8, gap: 2, op: 0.85 },
    breath:  { h: 3, gap: 1, op: 0.4 },
  };
  const p = presets[variant];
  return (
    <div style={{
      display: 'flex', gap: p.gap, padding: 1,
      border: `1px solid ${NC.ground3}`,
      background: NC.grout,
      opacity: p.op,
      ...style,
    }}>
      {SHARD_COLORS.map((c,i) => (
        <div key={i} style={{ flex: 1, height: p.h, background: c }} />
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Section tag — mono · spaced · uppercase · with trailing hairline.
function SectionTag({ children, style }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      fontFamily: NC.mono, fontSize: 10, fontWeight: 400,
      letterSpacing: '3px', textTransform: 'uppercase',
      color: NC.text3,
      ...style,
    }}>
      <span style={{ whiteSpace: 'nowrap' }}>{children}</span>
      <span style={{ flex: 1, height: 1, background: NC.ground4 }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Skyline — Chicago horizon, very low opacity, sits behind titles.
function SkylineSvg({ opacity = 0.22, color = NC.text0, style }) {
  return (
    <svg viewBox="0 0 370 80" style={{ width: '100%', display: 'block', opacity, ...style }} preserveAspectRatio="xMidYEnd meet">
      <path fill={color} d="
        M0 80 V62 H8 V58 H14 V62 H22 V52 H30 V62 H36 V48 H44 V62
        H52 V40 H60 V62 H72 V36 H80 V32 H86 V36 H94 V62
        H102 V44 H110 V20 L114 16 L118 20 V44 H126 V12 L130 8 L134 12 V44 H142 V20 H150 V62
        H162 V30 H170 V62 H178 V24 H188 V62
        H200 V14 H218 V62
        H226 V36 H234 V62
        H248 V46 H258 V62
        H268 V40 H276 V62
        H286 V52 H294 V62
        H306 V44 H314 V62
        H324 V50 H332 V62
        H342 V56 H350 V62
        H362 V60 H370 V80 Z
      "/>
      {/* X-bracing on the tallest tower */}
      <g stroke={color} strokeWidth="0.8" fill="none" opacity="0.6">
        <path d="M110 24 L126 44 M126 24 L110 44 M110 34 H126" />
      </g>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Shard balance chip — top-right of every screen.
function ShardChip({ count = 47 }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '6px 12px',
      background: NC.ground2,
      border: `1px solid ${NC.ground4}`,
    }}>
      <span style={{
        width: 8, height: 8, transform: 'rotate(45deg)',
        background: NC.sGold,
        boxShadow: `0 0 6px ${NC.sGold}80`,
      }}/>
      <span style={{
        fontFamily: NC.mono, fontSize: 13, fontWeight: 700,
        color: NC.sGold, fontVariantNumeric: 'tabular-nums',
      }}>{count}</span>
      <span style={{
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
        textTransform: 'uppercase', color: NC.text3,
      }}>shards</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// NavContext — lets PageHeader/SubHeader open the side menu without
// every screen having to thread setOpen down by hand.
const NavContext = React.createContext({ active: 'dashboard', open: false, setOpen: () => {} });

// Hamburger glyph — three hairlines, styled like a stained-glass leading.
function Hamburger({ onClick }) {
  return (
    <button onClick={onClick} style={{
      width: 30, height: 30, padding: 0,
      background: 'transparent',
      border: `1px solid ${NC.ground4}`,
      display: 'inline-flex', flexDirection: 'column', justifyContent: 'center',
      gap: 4, alignItems: 'center',
      cursor: 'pointer',
    }}>
      <span style={{ width: 14, height: 1, background: NC.text1 }}/>
      <span style={{ width: 14, height: 1, background: NC.text1 }}/>
      <span style={{ width: 14, height: 1, background: NC.text1 }}/>
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// Page header — hamburger left, brand center-ish, shard chip right.
function PageHeader({ shards = 47 }) {
  const nav = React.useContext(NavContext);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 10,
      padding: '12px 16px 10px',
      borderBottom: `1px solid ${NC.ground3}`,
      background: NC.ground1,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
        <Hamburger onClick={() => nav.setOpen(true)} />
        <span style={{
          width: 20, height: 20, display: 'inline-block', flexShrink: 0,
          background: `linear-gradient(135deg, ${NC.sGold} 0%, ${NC.sRose} 50%, ${NC.sBlue} 100%)`,
          clipPath: 'polygon(50% 0, 100% 38%, 82% 100%, 18% 100%, 0 38%)',
        }}/>
        <span style={{
          fontFamily: NC.serif, fontSize: 16, fontWeight: 500,
          color: NC.text0, letterSpacing: '-0.01em',
        }}>Null City</span>
      </div>
      <ShardChip count={shards} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SideMenu — left drawer that replaces the bottom tab bar.
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Home',           glyph: 'H' },
  { id: 'wall',      label: 'The Wall',       glyph: 'W' },
  { id: 'rooms',     label: 'Rooms',          glyph: 'R' },
  { id: 'inbox',     label: 'Inbox',          glyph: 'I', badge: 2 },
  { id: 'redeem',    label: 'Redeem',         glyph: 'S' },
];
const NAV_CITY_ITEMS = [
  { id: 'library',   label: 'Library of Souls', glyph: '†' },
  { id: 'embassy',   label: 'The Embassy',      glyph: '❖' },
  { id: 'public',    label: 'Public Wall View', glyph: '▣' },
];

function NavRow({ item, active, muted }) {
  const on = !!active;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '11px 18px',
      background: on ? NC.ground2 : 'transparent',
      borderLeft: `3px solid ${on ? NC.sGold : 'transparent'}`,
      cursor: 'pointer',
    }}>
      <span style={{
        width: 24, height: 24,
        border: `1px solid ${on ? NC.sGold : muted ? NC.ground4 : NC.ground4}`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: NC.serif, fontSize: 12, fontWeight: 500,
        color: on ? NC.sGold : muted ? NC.text3 : NC.text2,
      }}>{item.glyph}</span>
      <span style={{
        flex: 1,
        fontFamily: NC.serif, fontSize: 15, fontWeight: 400,
        color: on ? NC.text0 : muted ? NC.text3 : NC.text1,
        letterSpacing: '-0.005em',
      }}>{item.label}</span>
      {item.badge && (
        <span style={{
          fontFamily: NC.mono, fontSize: 9, fontWeight: 700,
          color: NC.ground0, background: NC.sGold,
          padding: '2px 7px', minWidth: 18, textAlign: 'center',
        }}>{item.badge}</span>
      )}
    </div>
  );
}

function SideMenu({ active, onClose, shards = 47 }) {
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 100,
      display: 'flex',
    }}>
      {/* Drawer */}
      <div style={{
        position: 'relative',
        width: 290, height: '100%',
        background: NC.ground1,
        borderRight: `1px solid ${NC.ground3}`,
        display: 'flex', flexDirection: 'column',
        boxShadow: '6px 0 24px rgba(0,0,0,0.6)',
      }}>
        {/* Drawer header */}
        <div style={{
          padding: '18px 18px 14px',
          borderBottom: `1px solid ${NC.ground3}`,
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
          gap: 12,
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                width: 22, height: 22, display: 'inline-block',
                background: `linear-gradient(135deg, ${NC.sGold} 0%, ${NC.sRose} 50%, ${NC.sBlue} 100%)`,
                clipPath: 'polygon(50% 0, 100% 38%, 82% 100%, 18% 100%, 0 38%)',
              }}/>
              <span style={{
                fontFamily: NC.serif, fontSize: 17, fontWeight: 500,
                color: NC.text0, letterSpacing: '-0.01em',
              }}>Null City</span>
            </div>
            <div style={{
              marginTop: 10,
              fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.8,
              textTransform: 'uppercase', color: NC.text3,
            }}>Visitor</div>
            <div style={{
              marginTop: 2,
              fontFamily: NC.serif, fontSize: 14, color: NC.text1,
              fontStyle: 'italic',
            }}>pendragon.eth</div>
          </div>
          <button onClick={onClose} style={{
            width: 28, height: 28, padding: 0,
            background: 'transparent',
            border: `1px solid ${NC.ground4}`,
            color: NC.text2, cursor: 'pointer',
            fontFamily: NC.serif, fontSize: 16, lineHeight: 1,
          }}>{'\u2715'}</button>
        </div>

        {/* Nav */}
        <div style={{ overflowY: 'auto', flex: 1 }}>
          <div style={{
            padding: '14px 18px 8px',
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
            textTransform: 'uppercase', color: NC.text3,
          }}>Navigate</div>
          {NAV_ITEMS.map(it => (
            <NavRow key={it.id} item={it} active={it.id === active}/>
          ))}

          <div style={{
            padding: '18px 18px 8px',
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
            textTransform: 'uppercase', color: NC.text3,
          }}>The city</div>
          {NAV_CITY_ITEMS.map(it => (
            <NavRow key={it.id} item={it} muted={it.id === 'public'}/>
          ))}

          <div style={{ padding: '18px 18px 0' }}>
            <ShardLine variant="default"/>
          </div>

          {/* Faction standings recap */}
          <div style={{
            padding: '18px 18px 8px',
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
            textTransform: 'uppercase', color: NC.text3,
          }}>Your standing</div>
          <div style={{ padding: '0 14px 14px' }}>
            {FACTIONS.map(f => (
              <div key={f.id} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '6px 4px',
              }}>
                <span style={{
                  width: 10, height: 10, background: f.color,
                  boxShadow: f.id === 'locksmiths' ? `0 0 4px ${NC.sRose}` : 'none',
                }}/>
                <span style={{
                  flex: 1,
                  fontFamily: NC.serif, fontSize: 12, color: NC.text1,
                }}>{f.short}</span>
                <span style={{
                  fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
                  textTransform: 'uppercase', color: NC.text3,
                }}>{f.standing}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div style={{
          padding: '12px 16px 16px',
          borderTop: `1px solid ${NC.ground3}`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          gap: 10,
        }}>
          <ShardChip count={shards}/>
          <span style={{
            fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.6,
            textTransform: 'uppercase', color: NC.text3,
            cursor: 'pointer', borderBottom: `1px solid ${NC.ground4}`,
          }}>Sign out</span>
        </div>
      </div>

      {/* Scrim — closes menu on tap */}
      <div onClick={onClose} style={{
        flex: 1, height: '100%',
        background: 'rgba(5,4,3,0.72)',
        backdropFilter: 'blur(2px)',
        WebkitBackdropFilter: 'blur(2px)',
        cursor: 'pointer',
      }}/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// NavShell — the screen root. Provides NavContext, owns the menu state,
// renders the SideMenu overlay when open. Each screen wraps its content
// with this instead of a bare <div>.
function NavShell({ active = 'dashboard', defaultOpen = false, shards = 47, children }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <NavContext.Provider value={{ active, open, setOpen }}>
      <div style={{
        position: 'relative',
        background: NC.ground0, color: NC.text1,
        fontFamily: NC.sans,
        minHeight: '100%', display: 'flex', flexDirection: 'column',
        paddingTop: 47,
      }}>
        {children}
        {open && <SideMenu active={active} onClose={() => setOpen(false)} shards={shards}/>}
      </div>
    </NavContext.Provider>
  );
}

// ─────────────────────────────────────────────────────────────
// Sub-page header — hamburger + back arrow + breadcrumb + shard chip.
function SubHeader({ back = 'Rooms', title, shards = 47 }) {
  const nav = React.useContext(NavContext);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      gap: 10,
      padding: '12px 14px 10px',
      borderBottom: `1px solid ${NC.ground3}`,
      background: NC.ground1,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
        <Hamburger onClick={() => nav.setOpen(true)} />
        <span style={{
          width: 24, height: 24,
          border: `1px solid ${NC.ground4}`,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: NC.text1, flexShrink: 0,
          fontFamily: NC.serif, fontSize: 14,
        }}>{'\u2190'}</span>
        <div style={{ minWidth: 0 }}>
          <div style={{
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.8,
            textTransform: 'uppercase', color: NC.text3,
          }}>{back}</div>
          <div style={{
            fontFamily: NC.serif, fontSize: 15, fontWeight: 500,
            color: NC.text0, letterSpacing: '-0.01em',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            maxWidth: 180,
          }}>{title}</div>
        </div>
      </div>
      <ShardChip count={shards} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Emotion presets — drive avatar palette + drift.
const EMOTIONS = {
  stillness: { palette: [NC.sBone, NC.ground5, NC.ground4],            accent: NC.sBone,  blurb: 'frozen, neutral.' },
  reverie:   { palette: [NC.sGold, NC.sAmber, NC.ground4, NC.sBone],   accent: NC.sGold,  blurb: 'gold + amber, slow swing.' },
  unease:    { palette: [NC.sMauve, NC.sBlue, NC.ground3, NC.sBone],   accent: NC.sMauve, blurb: 'mauve + blue, faster.' },
  anguish:   { palette: [NC.sRose, NC.sMauve, NC.ground3, NC.sBone],   accent: NC.sRose,  blurb: 'rose + mauve, fast.' },
  fury:      { palette: [NC.sRose, NC.sAmber, NC.sGold, NC.ground3],   accent: NC.sRose,  blurb: 'rose + amber, fastest.' },
};

// ─────────────────────────────────────────────────────────────
// SimpleStainedGlass — SVG voronoi-ish polygon mosaic for avatars.
// Deterministic for a given seed + emotion.
function SimpleStainedGlass({ size = 180, emotion = 'reverie', monogram = 'M', seed = 1, style }) {
  const palette = EMOTIONS[emotion].palette;
  // seeded prng (mulberry32)
  function rng(s) {
    return () => {
      s |= 0; s = (s + 0x6D2B79F5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const r = rng(seed * 9301);

  // Generate ~22 points jittered on a 5x5 grid.
  const pts = [];
  for (let y = 0; y < 5; y++) {
    for (let x = 0; x < 5; x++) {
      pts.push([
        ((x + 0.5) / 5) * 100 + (r() - 0.5) * 14,
        ((y + 0.5) / 5) * 100 + (r() - 0.5) * 14,
      ]);
    }
  }
  // Approximate voronoi by sampling each pixel — too expensive; instead
  // build polygons as small jittered rectangles around each point.
  const cells = pts.map(([cx, cy], i) => {
    const w = 18 + r() * 6;
    const h = 18 + r() * 6;
    const rot = (r() - 0.5) * 30;
    return {
      cx, cy, w, h, rot,
      color: palette[i % palette.length],
      depth: r() < 0.33 ? 'near' : r() < 0.5 ? 'deep' : 'middle',
    };
  });

  return (
    <div style={{
      position: 'relative', width: size, height: size, overflow: 'hidden',
      background: '#050403',
      border: `1px solid ${NC.ground4}`,
      ...style,
    }}>
      <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {cells.map((c, i) => (
          <rect key={i}
            x={c.cx - c.w/2} y={c.cy - c.h/2}
            width={c.w} height={c.h}
            transform={`rotate(${c.rot} ${c.cx} ${c.cy})`}
            fill={c.color}
            opacity={c.depth === 'deep' ? 0.45 : c.depth === 'middle' ? 0.78 : 0.92}
            style={{ mixBlendMode: 'screen' }}
          />
        ))}
        {/* dark vignette mask */}
        <radialGradient id={`vg-${seed}`} cx="50%" cy="50%" r="65%">
          <stop offset="60%" stopColor="#000" stopOpacity="0"/>
          <stop offset="100%" stopColor="#000" stopOpacity="0.7"/>
        </radialGradient>
        <rect width="100" height="100" fill={`url(#vg-${seed})`}/>
      </svg>
      {/* leaded grid hairlines */}
      <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
        {[20, 40, 60, 80].map(v => (
          <React.Fragment key={v}>
            <line x1={v} y1="0" x2={v} y2="100" stroke="#0E0C0A" strokeWidth="0.6" opacity="0.7"/>
            <line x1="0" y1={v} x2="100" y2={v} stroke="#0E0C0A" strokeWidth="0.6" opacity="0.7"/>
          </React.Fragment>
        ))}
      </svg>
      {/* monogram */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: NC.serif, fontWeight: 900,
        fontSize: size * 0.46, color: NC.text0, opacity: 0.12,
        letterSpacing: '-0.04em',
        textShadow: '0 0 12px rgba(237,232,224,0.18)',
      }}>{monogram}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Fake parcel territory data for The Wall (50×50 grid).
// Returns array of {x, y, faction} cells. Deterministic.
function buildParcels() {
  const cells = [];
  const has = new Set();
  function add(x, y, f) {
    if (x < 0 || y < 0 || x > 49 || y > 49) return;
    const k = `${x},${y}`;
    if (has.has(k)) return;
    has.add(k);
    cells.push({ x, y, faction: f });
  }
  function blob(cx, cy, count, faction, rng) {
    // grow a blob from a seed using a small PRNG.
    add(cx, cy, faction);
    let frontier = [[cx, cy]];
    while (cells.filter(c => c.faction === faction).length < count && frontier.length) {
      const idx = Math.floor(rng() * frontier.length);
      const [x, y] = frontier.splice(idx, 1)[0];
      const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
      // shuffle
      for (let i = dirs.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i+1));
        [dirs[i], dirs[j]] = [dirs[j], dirs[i]];
      }
      for (const [dx, dy] of dirs) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx > 49 || ny > 49) continue;
        if (has.has(`${nx},${ny}`)) continue;
        if (rng() < 0.72) {
          add(nx, ny, faction);
          frontier.push([nx, ny]);
        }
      }
    }
  }
  // mulberry32
  function rng(seed) {
    return () => {
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  blob(10, 12, 47, 'saints',        rng(1));
  blob(38, 9,  38, 'hatchery',      rng(2));
  blob(24, 32, 19, 'locksmiths',    rng(3));
  blob(34, 38, 41, 'ledgerwrights', rng(4));
  return cells;
}

// expose to other babel scripts
Object.assign(window, {
  NC, SHARD_COLORS, FACTIONS, STANDING_TIERS, tierIdx,
  EMOTIONS,
  ShardLine, SectionTag, SkylineSvg, ShardChip,
  PageHeader, SubHeader, SideMenu, NavShell, NavContext,
  SimpleStainedGlass, buildParcels,
});
