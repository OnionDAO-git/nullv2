// Redeem — resources → achievements. Recipe progress + redeem buttons.

const RESOURCES = {
  // saints
  flux_drop:        { name: 'Flux Drop',         tier: 'T1', cost: 2,  faction: 'saints' },
  signed_schematic: { name: 'Signed Schematic',  tier: 'T2', cost: 6,  faction: 'saints' },
  reliquary_board:  { name: 'Reliquary Board',   tier: 'T3', cost: 15, faction: 'saints' },
  // hatchery
  token_crumb:      { name: 'Token Crumb',       tier: 'T1', cost: 2,  faction: 'hatchery' },
  echo_fragment:    { name: 'Echo Fragment',     tier: 'T2', cost: 6,  faction: 'hatchery' },
  lineage_scroll:   { name: 'Lineage Scroll',    tier: 'T3', cost: 15, faction: 'hatchery' },
  // locksmiths
  tumbler_pin:      { name: 'Tumbler Pin',       tier: 'T1', cost: 2,  faction: 'locksmiths' },
  master_bypass:    { name: 'Master Bypass',     tier: 'T2', cost: 6,  faction: 'locksmiths' },
  vault_charter:    { name: 'Vault Charter',     tier: 'T3', cost: 15, faction: 'locksmiths' },
  // ledgerwrights
  mempool_mote:     { name: 'Mempool Mote',      tier: 'T1', cost: 2,  faction: 'ledgerwrights' },
  block_seal:       { name: 'Block Seal',        tier: 'T2', cost: 6,  faction: 'ledgerwrights' },
  genesis_crumb:    { name: 'Genesis Crumb',     tier: 'T3', cost: 15, faction: 'ledgerwrights' },
};

// Visitor's current resource inventory (counts).
const INVENTORY = {
  flux_drop: 3, signed_schematic: 1, reliquary_board: 0,
  token_crumb: 2, echo_fragment: 1, lineage_scroll: 0,
  tumbler_pin: 1, master_bypass: 0, vault_charter: 0,
  mempool_mote: 2, block_seal: 1, genesis_crumb: 0,
};

const ACHIEVEMENTS = [
  // single-faction
  { id: 'soldered_halo',  kind: 'single', faction: 'saints',
    name: 'The Soldered Halo',
    flavor: 'a small circle of copper, soldered while still warm.',
    recipe: [['flux_drop', 2], ['signed_schematic', 1]] },
  { id: 'hatched_egg',    kind: 'single', faction: 'hatchery',
    name: 'The Hatched Egg',
    flavor: 'cracked from the inside, never the outside.',
    recipe: [['token_crumb', 2], ['echo_fragment', 1]] },
  { id: 'master_key',     kind: 'single', faction: 'locksmiths',
    name: 'The Master Key',
    flavor: 'opens nothing in particular. opens enough.',
    recipe: [['tumbler_pin', 2], ['master_bypass', 1]] },
  { id: 'signed_block',   kind: 'single', faction: 'ledgerwrights',
    name: 'The Signed Block',
    flavor: 'a small confirmation that the city happened today.',
    recipe: [['mempool_mote', 2], ['block_seal', 1]] },
  // cross-faction
  { id: 'embodied_mind',  kind: 'cross',
    factions: ['saints','hatchery'],
    name: 'The Embodied Mind',
    flavor: 'the resident was given a body. the body was given a name.',
    recipe: [['reliquary_board', 1], ['lineage_scroll', 1]] },
  { id: 'sealed_sandbox', kind: 'cross',
    factions: ['hatchery','locksmiths'],
    name: 'The Sealed Sandbox',
    flavor: 'a small world, carefully kept from the larger one.',
    recipe: [['lineage_scroll', 1], ['vault_charter', 1]] },
  // civic
  { id: 'first_shard',    kind: 'civic',
    name: 'The First Shard',
    flavor: 'bestowed on the night you first crossed the threshold.',
    granted: true },
  { id: 'morticians_ribbon', kind: 'civic',
    name: 'The Mortician\u2019s Ribbon',
    flavor: 'for those who filed an epitaph in the library of souls.',
    granted: false },
];

function FilterChips({ active, onChange }) {
  const opts = [
    { id: 'all',    label: 'All' },
    { id: 'single', label: 'Single-faction' },
    { id: 'cross',  label: 'Cross-faction' },
    { id: 'civic',  label: 'Civic' },
  ];
  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {opts.map(o => {
        const on = active === o.id;
        return (
          <button key={o.id} onClick={() => onChange(o.id)} style={{
            background: on ? NC.ground3 : 'transparent',
            border: `1px solid ${on ? NC.sGold : NC.ground4}`,
            color: on ? NC.sGold : NC.text2,
            padding: '6px 12px',
            fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.6,
            textTransform: 'uppercase', cursor: 'pointer',
          }}>{o.label}</button>
        );
      })}
    </div>
  );
}

function RecipeIngredient({ resourceId, need }) {
  const r = RESOURCES[resourceId];
  const have = INVENTORY[resourceId] || 0;
  const ok = have >= need;
  const f = FACTIONS.find(x => x.id === r.faction);
  const isLocks = r.faction === 'locksmiths';
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'auto 1fr auto',
      alignItems: 'center', gap: 10,
      padding: '10px 0',
      borderBottom: `1px solid ${NC.ground2}`,
    }}>
      <span style={{
        width: 10, height: 10, background: f.color,
        boxShadow: isLocks ? `0 0 5px ${NC.sRose}99` : 'none',
      }}/>
      <div>
        <div style={{
          fontFamily: NC.serif, fontSize: 13, fontWeight: 500,
          color: ok ? NC.text0 : NC.text2,
        }}>{r.name}</div>
        <div style={{
          marginTop: 2,
          fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
          textTransform: 'uppercase', color: NC.text3,
        }}>{r.tier} &middot; {r.cost} shards</div>
      </div>
      <div style={{
        fontFamily: NC.mono, fontSize: 12, fontWeight: 700,
        color: ok ? NC.sGreen : NC.sRose,
        fontVariantNumeric: 'tabular-nums',
      }}>
        {have}<span style={{ color: NC.text3, fontWeight: 400 }}>/{need}</span>
      </div>
    </div>
  );
}

function AchievementCard({ a }) {
  // determine accent for left bar
  let leftBar;
  if (a.kind === 'single') {
    const c = FACTIONS.find(x => x.id === a.faction).color;
    leftBar = <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: c }} />;
  } else if (a.kind === 'cross') {
    const c1 = FACTIONS.find(x => x.id === a.factions[0]).color;
    const c2 = FACTIONS.find(x => x.id === a.factions[1]).color;
    leftBar = (
      <React.Fragment>
        <span style={{ position: 'absolute', left: 0, top: 0, height: '50%', width: 3, background: c1 }} />
        <span style={{ position: 'absolute', left: 0, bottom: 0, height: '50%', width: 3, background: c2 }} />
      </React.Fragment>
    );
  } else {
    leftBar = <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3,
      backgroundImage: `repeating-linear-gradient(180deg, ${NC.text3} 0 4px, transparent 4px 8px)` }} />;
  }

  // recipe progress
  let canRedeem = false;
  let recipeNode = null;
  if (a.recipe) {
    canRedeem = a.recipe.every(([rid, n]) => (INVENTORY[rid] || 0) >= n);
    recipeNode = (
      <div style={{ marginTop: 4 }}>
        <div style={{
          fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
          textTransform: 'uppercase', color: NC.text3,
          paddingBottom: 4, borderBottom: `1px solid ${NC.ground3}`,
          marginBottom: 0,
        }}>Recipe</div>
        {a.recipe.map(([rid, n]) => (
          <RecipeIngredient key={rid} resourceId={rid} need={n} />
        ))}
      </div>
    );
  }

  return (
    <div style={{
      position: 'relative',
      background: NC.ground1,
      border: `1px solid ${NC.ground3}`,
      padding: '16px 18px 14px 18px',
    }}>
      {leftBar}
      {/* header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
        <div>
          <div style={{
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
            textTransform: 'uppercase', color: NC.text3,
          }}>{a.kind === 'civic' ? 'Civic Achievement' : a.kind === 'cross' ? 'Cross-Faction' : 'Single-Faction'}</div>
          <div style={{
            marginTop: 4,
            fontFamily: NC.serif, fontSize: 19, fontWeight: 500,
            color: NC.text0, letterSpacing: '-0.01em',
          }}>{a.name}</div>
        </div>
        {a.kind === 'civic' && (
          <span style={{
            fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
            textTransform: 'uppercase',
            color: a.granted ? NC.sGold : NC.text3,
            border: `1px solid ${a.granted ? NC.sGold : NC.ground4}`,
            padding: '3px 8px', whiteSpace: 'nowrap',
          }}>{a.granted ? 'Granted' : 'Pending'}</span>
        )}
      </div>

      {/* flavor */}
      <div style={{
        marginTop: 10,
        fontFamily: NC.serif, fontStyle: 'italic',
        fontSize: 12.5, color: NC.text2, lineHeight: 1.5,
      }}>{a.flavor}</div>

      {/* recipe (none for civic) */}
      {a.recipe && (
        <div style={{ marginTop: 14 }}>{recipeNode}</div>
      )}

      {/* action */}
      <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 12 }}>
        {a.kind === 'civic' ? (
          <span style={{
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 12, color: NC.text3,
          }}>{a.granted ? 'bestowed by the embassy.' : 'awaiting the embassy\u2019s notice.'}</span>
        ) : (
          <button style={{
            flex: 1, padding: '11px 14px',
            background: canRedeem ? NC.sGold : 'transparent',
            color: canRedeem ? NC.ground0 : NC.text3,
            border: `1px solid ${canRedeem ? NC.sGold : NC.ground4}`,
            fontFamily: NC.mono, fontSize: 10, fontWeight: 700,
            letterSpacing: 2, textTransform: 'uppercase',
            cursor: canRedeem ? 'pointer' : 'not-allowed',
          }}>{canRedeem ? 'Redeem \u2192 print lanyard' : 'short on resources'}</button>
        )}
      </div>
    </div>
  );
}

function InventorySummary() {
  const totalResources = Object.values(INVENTORY).reduce((a,b) => a+b, 0);
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10,
    }}>
      <div style={{
        background: NC.ground1, border: `1px solid ${NC.ground3}`,
        padding: '14px 14px',
      }}>
        <div style={{
          fontFamily: NC.mono, fontSize: 28, fontWeight: 700,
          color: NC.sGold, fontVariantNumeric: 'tabular-nums',
          letterSpacing: '-0.02em', lineHeight: 1,
        }}>47</div>
        <div style={{
          marginTop: 6,
          fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
          textTransform: 'uppercase', color: NC.text3,
        }}>Shards on hand</div>
      </div>
      <div style={{
        background: NC.ground1, border: `1px solid ${NC.ground3}`,
        padding: '14px 14px',
      }}>
        <div style={{
          fontFamily: NC.mono, fontSize: 28, fontWeight: 700,
          color: NC.text0, fontVariantNumeric: 'tabular-nums',
          letterSpacing: '-0.02em', lineHeight: 1,
        }}>{totalResources}</div>
        <div style={{
          marginTop: 6,
          fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
          textTransform: 'uppercase', color: NC.text3,
        }}>Resources gathered</div>
      </div>
    </div>
  );
}

function ResourceMatrix() {
  return (
    <div style={{
      background: NC.ground1, border: `1px solid ${NC.ground3}`,
    }}>
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 28px 28px 28px',
        padding: '10px 14px',
        borderBottom: `1px solid ${NC.ground3}`,
        gap: 8,
        fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
        textTransform: 'uppercase', color: NC.text3,
      }}>
        <span>Faction</span>
        <span style={{ textAlign: 'center' }}>T1</span>
        <span style={{ textAlign: 'center' }}>T2</span>
        <span style={{ textAlign: 'center' }}>T3</span>
      </div>
      {FACTIONS.map((f, i) => {
        const tiers = Object.values(RESOURCES).filter(r => r.faction === f.id);
        const isLocks = f.id === 'locksmiths';
        return (
          <div key={f.id} style={{
            display: 'grid',
            gridTemplateColumns: '1fr 28px 28px 28px',
            padding: '11px 14px',
            gap: 8, alignItems: 'center',
            borderBottom: i < FACTIONS.length - 1 ? `1px solid ${NC.ground2}` : 'none',
            borderLeft: `3px solid ${f.color}`,
          }}>
            <span style={{
              fontFamily: NC.serif, fontSize: 13, fontWeight: 500,
              color: NC.text0,
            }}>{f.short}</span>
            {tiers.map((r, j) => {
              const n = INVENTORY[Object.keys(RESOURCES).find(k => RESOURCES[k] === r)] || 0;
              return (
                <span key={j} style={{
                  textAlign: 'center',
                  fontFamily: NC.mono, fontSize: 13, fontWeight: 700,
                  color: n > 0 ? NC.text0 : NC.text3,
                  fontVariantNumeric: 'tabular-nums',
                }}>{n}</span>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

function RedeemScreen({ menuOpen = false }) {
  const [filter, setFilter] = React.useState('all');
  const visible = ACHIEVEMENTS.filter(a => filter === 'all' ? true : a.kind === filter);
  return (
    <NavShell active="redeem" defaultOpen={menuOpen} shards={47}>
      <PageHeader shards={47} />

      <div style={{ flex: 1 }}>
        <div style={{ position: 'relative', padding: '28px 20px 14px' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 8, pointerEvents: 'none' }}>
            <SkylineSvg opacity={0.14} />
          </div>
          <SectionTag style={{ position: 'relative', marginBottom: 18 }}>Redeem &middot; the library of recipes</SectionTag>
          <div style={{
            position: 'relative',
            fontFamily: NC.serif, fontWeight: 300,
            fontSize: 42, lineHeight: 0.95, letterSpacing: '-0.03em',
            color: NC.text0,
          }}>turn<br/>resources<br/><span style={{ color: NC.text2 }}>into ribbon.</span></div>
          <div style={{
            position: 'relative', marginTop: 12,
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 13, color: NC.text2, lineHeight: 1.5,
            maxWidth: 290,
          }}>each redeemed achievement is printed onto a small lanyard token &mdash; and ratifies a new parcel on the wall.</div>
        </div>

        <div style={{ padding: '8px 20px 0' }}>
          <InventorySummary />
        </div>

        <div style={{ padding: '20px 20px 0' }}>
          <SectionTag style={{ marginBottom: 12 }}>Inventory &middot; by faction</SectionTag>
          <ResourceMatrix />
        </div>

        <div style={{ padding: '24px 20px 14px' }}>
          <SectionTag style={{ marginBottom: 14 }}>Achievements</SectionTag>
          <FilterChips active={filter} onChange={setFilter} />
        </div>

        <div style={{
          padding: '4px 20px 0',
          display: 'flex', flexDirection: 'column', gap: 12,
        }}>
          {visible.map(a => <AchievementCard key={a.id} a={a} />)}
        </div>

        <div style={{ padding: '24px 20px 36px' }}>
          <ShardLine variant="breath" />
          <div style={{
            marginTop: 14, textAlign: 'center',
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 12, color: NC.text3,
          }}>their memory got a little of you in it.</div>
        </div>
      </div>

      </NavShell>
  );
}

window.RedeemScreen = RedeemScreen;
