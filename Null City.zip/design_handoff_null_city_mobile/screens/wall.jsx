// The Wall — full 50×50 parcel map, leaderboard, live ticker.

function WallMap({ parcels, big = false }) {
  return (
    <div style={{
      position: 'relative',
      background: '#050403',
      border: `1px solid ${NC.ground3}`,
      padding: 8,
    }}>
      <svg viewBox="0 0 50 50" style={{ width: '100%', display: 'block' }}>
        <defs>
          <pattern id="grid-wall" width="5" height="5" patternUnits="userSpaceOnUse">
            <path d="M 5 0 L 0 0 0 5" fill="none" stroke={NC.ground3} strokeWidth="0.08"/>
          </pattern>
        </defs>
        <rect width="50" height="50" fill="url(#grid-wall)" />
        {parcels.map((p, i) => {
          const f = FACTIONS.find(x => x.id === p.faction);
          const locks = p.faction === 'locksmiths';
          return (
            <rect key={i} x={p.x} y={p.y} width="1" height="1"
              fill={locks ? '#000' : f.color}
              opacity={locks ? 1 : 0.94}
              style={locks ? { filter: 'drop-shadow(0 0 0.4px rgba(212,112,122,0.7))' } : null}
            />
          );
        })}
        {/* embassy seed marker — small chalk halo center */}
        <circle cx="25" cy="25" r="0.6" fill="none" stroke={NC.text0} strokeWidth="0.12" opacity="0.5"/>
      </svg>
      <div style={{
        position: 'absolute', top: 12, left: 14,
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
        textTransform: 'uppercase', color: NC.text3,
      }}>50&times;50 grid</div>
      <div style={{
        position: 'absolute', bottom: 12, right: 14,
        fontFamily: NC.mono, fontSize: 9, letterSpacing: 2,
        textTransform: 'uppercase', color: NC.text2,
      }}>{parcels.length} parcels claimed</div>
    </div>
  );
}

function TerritoryLeaderboard({ parcels }) {
  const counts = FACTIONS.map(f => ({
    ...f,
    count: parcels.filter(p => p.faction === f.id).length,
  })).sort((a,b) => b.count - a.count);
  const max = counts[0].count;
  return (
    <div style={{
      background: NC.ground1,
      border: `1px solid ${NC.ground3}`,
    }}>
      {counts.map((f, i) => {
        const isLocks = f.id === 'locksmiths';
        return (
          <div key={f.id} style={{
            display: 'grid',
            gridTemplateColumns: 'auto 1fr auto',
            alignItems: 'center', gap: 12,
            padding: '12px 16px',
            borderBottom: i < counts.length - 1 ? `1px solid ${NC.ground2}` : 'none',
          }}>
            <span style={{
              width: 14, height: 14, background: f.color,
              boxShadow: isLocks ? `0 0 6px ${NC.sRose}80` : 'none',
              border: isLocks ? `1px solid ${NC.sRose}55` : 'none',
            }}/>
            <div>
              <div style={{
                fontFamily: NC.serif, fontSize: 14, fontWeight: 500,
                color: NC.text0,
              }}>{f.short}</div>
              <div style={{
                marginTop: 6,
                height: 1.5, background: NC.ground3, position: 'relative',
              }}>
                <div style={{
                  position: 'absolute', left: 0, top: 0, bottom: 0,
                  width: `${(f.count / max) * 100}%`,
                  background: f.color,
                  boxShadow: isLocks ? `0 0 4px ${NC.sRose}` : 'none',
                }}/>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{
                fontFamily: NC.mono, fontSize: 16, fontWeight: 700,
                color: NC.sGold, fontVariantNumeric: 'tabular-nums',
              }}>{f.count}</div>
              <div style={{
                fontFamily: NC.mono, fontSize: 8, letterSpacing: 1.5,
                textTransform: 'uppercase', color: NC.text3,
              }}>parcels</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function LiveTicker() {
  const events = [
    { icon: '🏆', color: NC.sGold,  text: 'pendragon.eth forged The Embodied Mind', t: '00:42' },
    { icon: '🥚', color: NC.sGreen, text: 'resident #214 \u2014 candlewright \u2014 was born', t: '01:08' },
    { icon: '💀', color: NC.sRose,  text: 'resident #199 went still', t: '03:14' },
    { icon: '🏆', color: NC.sGold,  text: 'mira.eth redeemed The Master Key', t: '04:50' },
    { icon: '🥚', color: NC.sGreen, text: 'resident #215 \u2014 brass-monk \u2014 was born', t: '06:22' },
  ];
  return (
    <div>
      <SectionTag style={{ marginBottom: 12 }}>Live &middot; ticker</SectionTag>
      <div style={{
        background: '#050403',
        border: `1px solid ${NC.ground3}`,
        maxHeight: 196, overflow: 'hidden',
      }}>
        {events.map((e, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '9px 14px',
            borderBottom: i < events.length - 1 ? `1px solid ${NC.ground2}` : 'none',
          }}>
            <span style={{ fontSize: 11, lineHeight: 1 }}>{e.icon}</span>
            <span style={{
              fontFamily: NC.sans, fontSize: 11, color: NC.text2,
              flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>{e.text}</span>
            <span style={{
              fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.5,
              color: NC.text3, fontVariantNumeric: 'tabular-nums',
            }}>{e.t}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function WallScreen({ menuOpen = false }) {
  const parcels = React.useMemo(() => buildParcels(), []);
  return (
    <NavShell active="wall" defaultOpen={menuOpen} shards={47}>
      <PageHeader shards={47} />

      <div style={{ flex: 1 }}>
        <div style={{ padding: '28px 20px 14px', position: 'relative' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 8, pointerEvents: 'none' }}>
            <SkylineSvg opacity={0.14} />
          </div>
          <SectionTag style={{ position: 'relative', marginBottom: 18 }}>The wall &middot; null city</SectionTag>
          <div style={{
            position: 'relative',
            fontFamily: NC.serif, fontWeight: 300,
            fontSize: 42, lineHeight: 0.95, letterSpacing: '-0.03em',
            color: NC.text0,
          }}>territory<br/><span style={{ color: NC.text2 }}>as claimed.</span></div>
          <div style={{
            position: 'relative', marginTop: 12,
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 13, color: NC.text2, lineHeight: 1.5,
            maxWidth: 290,
          }}>each parcel was once a redeemed achievement &mdash; a small piece of the city ratified into being.</div>
        </div>

        <div style={{ padding: '6px 20px 0' }}>
          <WallMap parcels={parcels} big />
        </div>

        <div style={{ padding: '24px 20px 8px' }}>
          <SectionTag style={{ marginBottom: 14 }}>Territory &middot; leaderboard</SectionTag>
          <TerritoryLeaderboard parcels={parcels} />
        </div>

        <div style={{
          margin: '18px 20px 0',
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10,
        }}>
          <Stat label="Total parcels" value={parcels.length} accent={NC.sGold} />
          <Stat label="Residents alive" value={47} accent={NC.sGreen} />
          <Stat label="Souls archived" value={12} accent={NC.sRose} />
          <Stat label="Days since seed" value={89} accent={NC.text1} />
        </div>

        <div style={{ padding: '24px 20px 16px' }}>
          <LiveTicker />
        </div>

        <div style={{ padding: '12px 20px 36px' }}>
          <ShardLine variant="breath" />
        </div>
      </div>

      </NavShell>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div style={{
      background: NC.ground1,
      border: `1px solid ${NC.ground3}`,
      padding: '12px 14px',
    }}>
      <div style={{
        fontFamily: NC.mono, fontSize: 22, fontWeight: 700,
        color: accent, fontVariantNumeric: 'tabular-nums',
        letterSpacing: '-0.02em',
      }}>{value}</div>
      <div style={{
        marginTop: 4,
        fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
        textTransform: 'uppercase', color: NC.text3,
      }}>{label}</div>
    </div>
  );
}

window.WallScreen = WallScreen;
