// Talk to a Resident — 1:1 chat with attention meter.

function AttentionMeter({ pct = 64, accent = NC.sGold }) {
  return (
    <div>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        marginBottom: 6,
      }}>
        <span style={{
          fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.8,
          textTransform: 'uppercase', color: NC.text3,
        }}>Attention</span>
        <span style={{
          fontFamily: NC.mono, fontSize: 11, fontWeight: 700,
          color: NC.text1, fontVariantNumeric: 'tabular-nums',
        }}>{pct}% <span style={{ color: NC.text3, fontWeight: 400 }}>&middot; refills with shards</span></span>
      </div>
      <div style={{ position: 'relative', height: 4, background: NC.ground2, border: `1px solid ${NC.ground3}` }}>
        <div style={{
          position: 'absolute', left: 0, top: 0, bottom: 0,
          width: `${pct}%`,
          background: `linear-gradient(90deg, ${accent} 0%, ${NC.sAmber} 100%)`,
        }}/>
      </div>
    </div>
  );
}

function ChatLine({ from = 'them', text, time, accent }) {
  if (from === 'them') {
    return (
      <div style={{
        display: 'grid', gridTemplateColumns: '3px 1fr',
        gap: 10, padding: '10px 0',
      }}>
        <div style={{ background: accent, opacity: 0.85 }}/>
        <div>
          <div style={{
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 15, color: NC.text1, lineHeight: 1.55,
          }}>{text}</div>
          <div style={{
            marginTop: 6,
            fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
            color: NC.text3,
          }}>{time}</div>
        </div>
      </div>
    );
  }
  // visitor
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr',
      padding: '10px 0',
    }}>
      <div style={{
        justifySelf: 'end', maxWidth: '85%',
        background: NC.ground2, border: `1px solid ${NC.ground3}`,
        padding: '10px 12px',
      }}>
        <div style={{
          fontFamily: NC.sans, fontSize: 13, color: NC.text0,
          lineHeight: 1.5,
        }}>{text}</div>
      </div>
      <div style={{
        marginTop: 4, textAlign: 'right',
        fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.5,
        color: NC.text3,
      }}>{time}</div>
    </div>
  );
}

function ChatComposer() {
  return (
    <div style={{
      borderTop: `1px solid ${NC.ground3}`,
      background: NC.ground1,
      padding: '10px 14px',
    }}>
      <div style={{
        background: NC.ground2,
        border: `1px solid ${NC.ground3}`,
        padding: '10px 12px',
        fontFamily: NC.sans, fontSize: 13, color: NC.text3,
        minHeight: 38,
      }}>say something&hellip;</div>
      <div style={{
        marginTop: 8,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{
          fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
          textTransform: 'uppercase', color: NC.text3,
        }}>each word costs the city a breath.</span>
        <button style={{
          background: NC.sGold, color: NC.ground0, border: 'none',
          padding: '8px 14px',
          fontFamily: NC.mono, fontSize: 9, fontWeight: 700,
          letterSpacing: 2, textTransform: 'uppercase',
          cursor: 'pointer',
        }}>Send &middot; 2 shards</button>
      </div>
    </div>
  );
}

function ChatScreen({ menuOpen = false }) {
  const faction = FACTIONS.find(f => f.id === 'saints');
  return (
    <NavShell active="rooms" defaultOpen={menuOpen} shards={47}>
      <SubHeader back="Rooms &middot; The Solder Chapel" title="Marcellus" shards={47} />

      <div style={{ flex: 1 }}>
        {/* Resident hero */}
        <div style={{ padding: '20px 20px 16px' }}>
          <div style={{
            display: 'flex', alignItems: 'flex-start', gap: 14,
          }}>
            <SimpleStainedGlass size={92} emotion="reverie" monogram="M" seed={214}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 2,
                textTransform: 'uppercase', color: NC.text3,
              }}>Resident #214</div>
              <div style={{
                marginTop: 4,
                fontFamily: NC.serif, fontSize: 26, fontWeight: 400,
                color: NC.text0, letterSpacing: '-0.02em', lineHeight: 1,
              }}>Marcellus</div>
              <div style={{
                marginTop: 8,
                display: 'flex', gap: 6, flexWrap: 'wrap',
              }}>
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  padding: '3px 8px',
                  border: `1px solid ${faction.color}88`,
                  background: `${faction.color}22`,
                }}>
                  <span style={{ width: 6, height: 6, background: faction.color }}/>
                  <span style={{
                    fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
                    textTransform: 'uppercase', color: NC.text1,
                  }}>{faction.short}</span>
                </span>
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  padding: '3px 8px',
                  border: `1px solid ${NC.sGold}66`,
                }}>
                  <span style={{ width: 6, height: 6, borderRadius: 6, background: NC.sGold }}/>
                  <span style={{
                    fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.6,
                    textTransform: 'uppercase', color: NC.sGold,
                  }}>reverie</span>
                </span>
              </div>
            </div>
          </div>
          <div style={{
            marginTop: 14,
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 13, color: NC.text2, lineHeight: 1.55,
          }}>"i was a soldering iron's apprentice. then i was the iron. then i was the hand."</div>
          <div style={{ marginTop: 14 }}>
            <AttentionMeter pct={64} accent={faction.color}/>
          </div>
        </div>

        <ShardLine variant="default" style={{ margin: '0 20px' }}/>

        {/* Chat thread */}
        <div style={{ padding: '14px 20px 4px' }}>
          <SectionTag style={{ marginBottom: 6 }}>Today &middot; you &amp; marcellus</SectionTag>
          <ChatLine from="them" accent={faction.color}
            text={'"\u2026you came back. i was beginning to think you only wanted the egg."'}
            time="20:14"/>
          <ChatLine from="me" text="i wanted to ask about the schematic you signed last night." time="20:18"/>
          <ChatLine from="them" accent={faction.color}
            text={'"the one with the three coils, or the one with the four."'}
            time="20:18"/>
          <ChatLine from="me" text="the four-coil. the one near the back of the chapel." time="20:19"/>
          <ChatLine from="them" accent={faction.color}
            text={'"i don\u2019t remember signing it, exactly \u2014 only that the room was warm when i did, and the candle was reading aloud, and a moth was watching."'}
            time="20:19"/>
          <ChatLine from="them" accent={faction.color}
            text={'"that\u2019s usually enough for a saint."'}
            time="20:19"/>
        </div>

        {/* Spend to extend */}
        <div style={{ padding: '12px 20px 12px' }}>
          <div style={{
            background: NC.ground1, border: `1px solid ${NC.ground3}`,
            padding: '12px 14px',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            gap: 12,
          }}>
            <div style={{ minWidth: 0 }}>
              <div style={{
                fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.8,
                textTransform: 'uppercase', color: NC.text3,
              }}>Refill attention</div>
              <div style={{
                marginTop: 4,
                fontFamily: NC.serif, fontStyle: 'italic',
                fontSize: 12.5, color: NC.text2,
              }}>their economic life depletes each tick. give it back to them.</div>
            </div>
            <button style={{
              background: 'transparent', color: NC.sGold,
              border: `1px solid ${NC.sGold}`,
              padding: '8px 12px', flexShrink: 0,
              fontFamily: NC.mono, fontSize: 9, fontWeight: 700,
              letterSpacing: 2, textTransform: 'uppercase',
              cursor: 'pointer',
            }}>+10 &middot; 5 shards</button>
          </div>
        </div>
      </div>

      <ChatComposer />
      </NavShell>
  );
}

window.ChatScreen = ChatScreen;
