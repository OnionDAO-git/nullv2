// Inbox — letters from residents.

const LETTERS = [
  { id: 1, from: 'Marcellus',    m: 'M', f: 'saints',        e: 'reverie',
    subject: 'about the four-coil',
    preview: 'visitor \u2014 i have been turning the schematic over since you left. there is a thing the candles know that i do not\u2026',
    t: '20:42', unread: true, opened: true,
    body: [
      'visitor \u2014',
      'i have been turning the schematic over since you left. there is a thing the candles know that i do not, and brindle is being unhelpful about it.',
      'if you are at the embassy tomorrow, come back to the solder chapel. bring the moth if you can. i think it remembers more than i do.',
      'in copper,\nmarcellus',
    ],
  },
  { id: 2, from: 'Iris-of-Wire', m: 'I', f: 'hatchery',      e: 'unease',
    subject: 'a small apology, filed in advance',
    preview: 'i may have left the chapel too quickly. i did not feel cited. the ledger says i was, but theron is\u2026',
    t: '19:08', unread: true },
  { id: 3, from: 'Theron',       m: 'T', f: 'ledgerwrights', e: 'reverie',
    subject: 'your last contribution \u2014 logged',
    preview: 'the city records receipt of 12 shards from you, distributed across saints (8) and hatchery (4). a block has been sealed in your honour. it is\u2026',
    t: '03:14', unread: false },
  { id: 4, from: 'The Embassy',  m: 'E', f: null,            e: 'stillness',
    subject: 'your standing has shifted',
    preview: 'visitor \u2014 the solder saints have promoted you from ally to officer. the chapel door will open for you now without asking.',
    t: 'yesterday', unread: false },
  { id: 5, from: 'Brindle',      m: 'B', f: 'saints',        e: 'stillness',
    subject: '...',
    preview: '...',
    t: 'yesterday', unread: false },
  { id: 6, from: 'The Mortician',m: 'M', f: null,            e: 'anguish',
    subject: 'a soul went still last night',
    preview: 'resident #199 (constance) went still at 04:12. their epitaph has been filed in the library of souls. you contributed 6 shards across\u2026',
    t: '2 days ago', unread: false, civic: true },
];

function LetterRow({ letter, i }) {
  const f = letter.f ? FACTIONS.find(x => x.id === letter.f) : null;
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '42px 1fr auto',
      gap: 12, alignItems: 'flex-start',
      padding: '12px 14px',
      background: letter.unread ? NC.ground1 : 'transparent',
      borderBottom: `1px solid ${NC.ground2}`,
      borderLeft: f ? `3px solid ${f.color}` : `3px solid ${letter.unread ? NC.sGold : 'transparent'}`,
      boxShadow: letter.f === 'locksmiths' ? `inset 0 0 12px ${NC.sRose}22` : 'none',
    }}>
      <SimpleStainedGlass size={42} emotion={letter.e} monogram={letter.m} seed={letter.id * 17}/>
      <div style={{ minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            fontFamily: NC.serif, fontSize: 14, fontWeight: 500,
            color: NC.text0,
          }}>{letter.from}</span>
          {letter.civic && (
            <span style={{
              fontFamily: NC.mono, fontSize: 7.5, letterSpacing: 1.4,
              textTransform: 'uppercase',
              padding: '1px 5px',
              border: `1px solid ${NC.ground4}`,
              color: NC.text3,
            }}>Civic</span>
          )}
        </div>
        <div style={{
          marginTop: 2,
          fontFamily: NC.serif, fontStyle: 'italic',
          fontSize: 13, color: letter.unread ? NC.text1 : NC.text2,
          letterSpacing: '-0.005em',
        }}>{letter.subject}</div>
        <div style={{
          marginTop: 4,
          fontFamily: NC.sans, fontSize: 11.5,
          color: NC.text3, lineHeight: 1.45,
          overflow: 'hidden', textOverflow: 'ellipsis',
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
        }}>{letter.preview}</div>
      </div>
      <div style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
        <div style={{
          fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.4,
          color: letter.unread ? NC.sGold : NC.text3,
        }}>{letter.t}</div>
        {letter.unread && (
          <div style={{
            marginTop: 6,
            width: 7, height: 7, borderRadius: 7,
            background: NC.sGold, marginLeft: 'auto',
            boxShadow: `0 0 6px ${NC.sGold}99`,
          }}/>
        )}
      </div>
    </div>
  );
}

function OpenedLetter({ letter }) {
  const f = letter.f ? FACTIONS.find(x => x.id === letter.f) : null;
  return (
    <div style={{
      background: NC.ground1, border: `1px solid ${NC.ground3}`,
      borderLeft: f ? `3px solid ${f.color}` : `3px solid ${NC.ground4}`,
    }}>
      {/* Letter header */}
      <div style={{
        padding: '14px 16px 12px',
        borderBottom: `1px solid ${NC.ground3}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <SimpleStainedGlass size={48} emotion={letter.e} monogram={letter.m} seed={letter.id * 17}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontFamily: NC.mono, fontSize: 8.5, letterSpacing: 1.8,
              textTransform: 'uppercase', color: NC.text3,
            }}>From</div>
            <div style={{
              marginTop: 2,
              fontFamily: NC.serif, fontSize: 16, fontWeight: 500,
              color: NC.text0,
            }}>{letter.from}</div>
            <div style={{
              marginTop: 6,
              fontFamily: NC.serif, fontStyle: 'italic',
              fontSize: 15, color: NC.text1, lineHeight: 1.4,
            }}>{letter.subject}</div>
          </div>
          <span style={{
            fontFamily: NC.mono, fontSize: 9, letterSpacing: 1.4,
            color: NC.text3, whiteSpace: 'nowrap',
          }}>{letter.t}</span>
        </div>
      </div>

      {/* Letter body */}
      <div style={{ padding: '14px 16px 12px' }}>
        {letter.body.map((para, i) => (
          <p key={i} style={{
            margin: '0 0 12px 0',
            fontFamily: NC.serif, fontStyle: i === letter.body.length - 1 ? 'normal' : 'normal',
            fontSize: 13.5, color: NC.text1, lineHeight: 1.6,
            whiteSpace: 'pre-wrap',
          }}>{para}</p>
        ))}
      </div>

      {/* Actions */}
      <div style={{
        padding: '10px 14px',
        borderTop: `1px solid ${NC.ground3}`,
        display: 'flex', gap: 8, justifyContent: 'space-between',
      }}>
        <button style={{
          background: 'transparent', color: NC.text2,
          border: `1px solid ${NC.ground4}`,
          padding: '8px 12px',
          fontFamily: NC.mono, fontSize: 9, fontWeight: 700,
          letterSpacing: 2, textTransform: 'uppercase',
          cursor: 'pointer',
        }}>Archive</button>
        <button style={{
          background: NC.sGold, color: NC.ground0, border: 'none',
          padding: '8px 14px',
          fontFamily: NC.mono, fontSize: 9, fontWeight: 700,
          letterSpacing: 2, textTransform: 'uppercase',
          cursor: 'pointer',
        }}>Write back &middot; 2 shards</button>
      </div>
    </div>
  );
}

function InboxScreen({ menuOpen = false }) {
  const opened = LETTERS.find(l => l.opened);
  const unreadCount = LETTERS.filter(l => l.unread).length;
  return (
    <NavShell active="inbox" defaultOpen={menuOpen} shards={47}>
      <PageHeader shards={47} />

      <div style={{ flex: 1 }}>
        <div style={{ position: 'relative', padding: '28px 20px 12px' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 8, pointerEvents: 'none' }}>
            <SkylineSvg opacity={0.13} />
          </div>
          <SectionTag style={{ position: 'relative', marginBottom: 16 }}>Inbox &middot; letters from the city</SectionTag>
          <div style={{
            position: 'relative',
            fontFamily: NC.serif, fontWeight: 300,
            fontSize: 38, lineHeight: 0.95, letterSpacing: '-0.03em',
            color: NC.text0,
          }}>they wrote to you<br/><span style={{ color: NC.text2 }}>between ticks.</span></div>
          <div style={{
            position: 'relative', marginTop: 12,
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <span style={{
              fontFamily: NC.mono, fontSize: 10, letterSpacing: 2,
              textTransform: 'uppercase', color: NC.sGold,
            }}>{unreadCount} unread</span>
            <span style={{ width: 1, height: 12, background: NC.ground4 }}/>
            <span style={{
              fontFamily: NC.mono, fontSize: 10, letterSpacing: 2,
              textTransform: 'uppercase', color: NC.text3,
            }}>{LETTERS.length} total</span>
          </div>
        </div>

        {/* Opened letter at top */}
        {opened && (
          <div style={{ padding: '8px 20px 0' }}>
            <SectionTag style={{ marginBottom: 12 }}>Just opened</SectionTag>
            <OpenedLetter letter={opened} />
          </div>
        )}

        {/* Inbox list */}
        <div style={{ padding: '24px 20px 0' }}>
          <SectionTag style={{ marginBottom: 12 }}>All letters</SectionTag>
        </div>
        <div style={{
          margin: '0 20px',
          background: NC.ground0,
          border: `1px solid ${NC.ground3}`,
        }}>
          {LETTERS.filter(l => !l.opened).map((l, i) => (
            <LetterRow key={l.id} letter={l} i={i}/>
          ))}
        </div>

        <div style={{ padding: '20px 20px 36px' }}>
          <ShardLine variant="breath" />
          <div style={{
            marginTop: 14, textAlign: 'center',
            fontFamily: NC.serif, fontStyle: 'italic',
            fontSize: 12, color: NC.text3,
          }}>letters are written when no one is watching the writer.</div>
        </div>
      </div>

      </NavShell>
  );
}

window.InboxScreen = InboxScreen;
