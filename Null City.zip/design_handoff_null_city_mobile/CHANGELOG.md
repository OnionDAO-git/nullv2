# CHANGELOG — Null City Mobile Wireframes

Reverse chronological. The README always reflects the latest revision; this file describes what changed and what implementers need to update.

---

## Revision 2 — Four new surfaces + side-drawer navigation

### New screens

Four screens were added to the visitor app. Specs are in `README.md` §§ Screens.

1. **Rooms** (`/rooms`, `/rooms/:roomId`) — eavesdrop on residents talking to each other in a chosen room. Horizontal room-switcher chips, occupants strip, live dialogue feed where each agent's line shows their stained-glass avatar, faction color, and emotion pill. A "Birth a Resident · 24 shards" CTA sits at the top of this screen.
2. **Talk to a Resident** (`/residents/:id`) — 1:1 chat with one resident. Stained-glass avatar hero, attention meter (depletes per tick, refillable for shards), italic-serif messages from the resident with a faction-color rule on the left, mono-flavored user messages right-aligned, composer that costs 2 shards per send.
3. **Birth a Resident** (`/rooms/birth` — modal-ish form) — spend shards to write a soul file. Live stained-glass preview, faction picker (4 tiles), emotion picker (5 horizontally-scrolling stained-glass swatches), motto textarea, lineage field. Itemized shard-cost summary (Quickening + Soul-file inscription + Hatchery tithe = 24). Below: "Your prior births" list.
4. **Inbox** (`/inbox`, `/inbox/:letterId`) — letters from residents. Opened letter rendered in full at the top; list of remaining letters below. Each row carries a stained-glass monogram, faction-color left-border, italic-serif subject, two-line preview, gold unread dot, and a `Civic` badge variant for embassy notices.

### Navigation pattern — REPLACED

The **bottom 5-tab nav bar has been removed**. Replace it with a **left side drawer** triggered by a hamburger button in the top-left of every screen header.

**What to update in your codebase:**

- **Remove** any `<TabBar>` / bottom-nav component you implemented from Revision 1.
- **Add** a hamburger button as the first child of both `PageHeader` and `SubHeader` — 30×30 box, 1px `--ground-4` border, three 14×1 hairlines in `--text-1` stacked with 4 px gaps, centered.
- **Add** a `<SideMenu>` drawer (290 px wide) that slides in from the left when the hamburger is tapped. Renders over the page content via `position: fixed; inset: 0; z-index: 100`, with a flex row containing the drawer (`width: 290px`) and a scrim (`flex: 1; background: rgba(5,4,3,0.72); backdrop-filter: blur(2px); cursor: pointer;`) that closes the drawer on tap. The drawer has a `boxShadow: 6px 0 24px rgba(0,0,0,0.6)`.
- **Drawer contents (top → bottom):**
  1. **Header** — brand mark (22×22 shard polygon with the same gold/rose/blue gradient as the page header) + "Null City" wordmark + a small "VISITOR" mono label + the visitor's handle in italic serif. Close button (`×`) in the top-right of the drawer.
  2. **NAVIGATE** section tag, then five nav rows: Home (`H`), The Wall (`W`), Rooms (`R`), Inbox (`I`, with a gold `2` badge for unread count), Redeem (`S`).
  3. **THE CITY** section tag, then three secondary nav rows: Library of Souls (`†`), The Embassy (`❖`), Public Wall View (`▣` — muted/disabled).
  4. A default `ShardLine` divider.
  5. **YOUR STANDING** section tag, then a recap row for each faction: 10×10 color swatch + faction short name in Outfit 500/12 + current tier label in mono uppercase.
  6. **Footer** — `border-top: 1px solid var(--ground-3)`, ShardChip on the left, "SIGN OUT" link on the right (mono 9, 1.6 px tracked, `--text-3`, single bottom border `--ground-4`).
- **Nav row anatomy:**
  - `display: flex; align-items: center; gap: 12px; padding: 11px 18px;`
  - Active row: `background: var(--ground-2); border-left: 3px solid var(--s-gold);` — glyph border + label color both shift to `--s-gold` / `--text-0`.
  - Inactive row: `border-left: 3px solid transparent;`
  - Muted row (disabled / coming-soon): glyph border `--ground-4`, label `--text-3`.
  - Glyph: 24×24 box with 1 px border, single Outfit 500/12 character centered.
  - Badge (right side, optional): gold rectangle (`background: var(--s-gold); color: var(--ground-0);` mono 9/700), 2 px vertical padding, 7 px horizontal padding, min-width 18 px.
- **Open/close behavior:** drawer is fully overlay (does not push content). Tapping the scrim or the `×` closes it. Animations stay slow per `DESIGN.md` §14 — 200 ms ease-out slide for the drawer, 200 ms fade for the scrim, no spring/overshoot.

### Header changes

Both `PageHeader` and `SubHeader` were updated:

- **PageHeader** (Home / Wall / Rooms / Inbox / Redeem) — `padding: 12px 16px 10px;` (was 20px sides). Layout: Hamburger → brand mark (now 20×20 instead of 22×22) → "Null City" wordmark — all on the left, with the ShardChip on the right.
- **SubHeader** (Birth / Talk to a Resident) — `padding: 12px 14px 10px;`. Layout: Hamburger → back-arrow box (24×24 — was 26×26) → breadcrumb stack (back-target in mono / current title in serif) → ShardChip on the right.

### Notes

- **Home indicator clearance** — without the bottom tab bar, content scrolls to within the home indicator area. Either bottom-pad each screen body by ≥32 px or anchor the home indicator to the device chrome (the iOS frame in the reference does the latter).
- **Per-screen `active` prop** — every page passes its own `active` id to the drawer so the correct row highlights when opened. Birth and Chat both pass `active="rooms"` since they're sub-pages of the Rooms surface.

### Files touched in this revision

- `screens/shared.jsx` — new `NavContext`, `NavShell`, `SideMenu`, `Hamburger` components, updated `PageHeader` + `SubHeader`, added `EMOTIONS` constant + `SimpleStainedGlass` SVG component. Removed `TabBar`.
- `screens/rooms.jsx`, `screens/chat.jsx`, `screens/birth.jsx`, `screens/inbox.jsx` — new.
- `screens/dashboard.jsx`, `screens/wall.jsx`, `screens/redeem.jsx` — wrapped in `NavShell`, removed `TabBar` usage.
- `Null City Mobile Wireframes.html` — 4 new artboards (Rooms / Chat / Birth / Inbox) + an 8th "Side Menu · Open" demo artboard that boots Dashboard with the drawer already open.

---

## Revision 1 — Initial handoff

Three primary visitor surfaces — Dashboard, The Wall, Redeem — on dark Null City surface with a 4-tab bottom nav. Faction standings, 50×50 parcel map, achievement recipes with redeem buttons.
